

public class Test {

	public void test() {
		Integer a = new Integer(5);
	}
}
