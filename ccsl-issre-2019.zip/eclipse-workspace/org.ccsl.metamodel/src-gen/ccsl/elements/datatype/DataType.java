/**
 */
package ccsl.elements.datatype;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Data Type</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ccsl.elements.datatype.DatatypePackage#getDataType()
 * @model
 * @generated
 */
public interface DataType extends EObject {
} // DataType
