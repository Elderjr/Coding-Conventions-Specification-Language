/**
 */
package ccsl.elements.namedElements;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Namespace</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link ccsl.elements.namedElements.Namespace#getOwnedNamedElements <em>Owned Named Elements</em>}</li>
 * </ul>
 *
 * @see ccsl.elements.namedElements.NamedElementsPackage#getNamespace()
 * @model
 * @generated
 */
public interface Namespace extends EObject {
	/**
	 * Returns the value of the '<em><b>Owned Named Elements</b></em>' containment reference list.
	 * The list contents are of type {@link ccsl.elements.namedElements.NamedElement}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Owned Named Elements</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Owned Named Elements</em>' containment reference list.
	 * @see ccsl.elements.namedElements.NamedElementsPackage#getNamespace_OwnedNamedElements()
	 * @model type="ccsl.elements.namedElements.NamedElement" containment="true"
	 * @generated
	 */
	EList getOwnedNamedElements();

} // Namespace
