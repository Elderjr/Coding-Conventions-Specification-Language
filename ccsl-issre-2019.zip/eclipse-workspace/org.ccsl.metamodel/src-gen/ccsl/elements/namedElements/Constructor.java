/**
 */
package ccsl.elements.namedElements;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Constructor</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ccsl.elements.namedElements.NamedElementsPackage#getConstructor()
 * @model
 * @generated
 */
public interface Constructor extends Method {
} // Constructor
