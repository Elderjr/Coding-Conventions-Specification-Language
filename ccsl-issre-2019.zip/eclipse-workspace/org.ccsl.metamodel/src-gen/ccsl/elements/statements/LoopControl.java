/**
 */
package ccsl.elements.statements;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Loop Control</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ccsl.elements.statements.StatementsPackage#getLoopControl()
 * @model
 * @generated
 */
public interface LoopControl extends ControlFlow {
} // LoopControl
