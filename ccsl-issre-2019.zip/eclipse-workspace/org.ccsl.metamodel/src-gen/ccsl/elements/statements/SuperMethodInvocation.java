/**
 */
package ccsl.elements.statements;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Super Method Invocation</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ccsl.elements.statements.StatementsPackage#getSuperMethodInvocation()
 * @model
 * @generated
 */
public interface SuperMethodInvocation extends MethodInvocation {
} // SuperMethodInvocation
