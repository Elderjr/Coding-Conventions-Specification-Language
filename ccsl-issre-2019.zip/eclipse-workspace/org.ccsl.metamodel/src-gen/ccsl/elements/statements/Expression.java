/**
 */
package ccsl.elements.statements;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Expression</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ccsl.elements.statements.StatementsPackage#getExpression()
 * @model
 * @generated
 */
public interface Expression extends Statement {
} // Expression
