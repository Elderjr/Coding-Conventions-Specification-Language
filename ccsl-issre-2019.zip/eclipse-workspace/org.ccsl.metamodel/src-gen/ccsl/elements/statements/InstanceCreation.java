/**
 */
package ccsl.elements.statements;

import ccsl.elements.namedElements.ComplexType;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Instance Creation</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link ccsl.elements.statements.InstanceCreation#getType <em>Type</em>}</li>
 * </ul>
 *
 * @see ccsl.elements.statements.StatementsPackage#getInstanceCreation()
 * @model
 * @generated
 */
public interface InstanceCreation extends MethodInvocation {
	/**
	 * Returns the value of the '<em><b>Type</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Type</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Type</em>' reference.
	 * @see #setType(ComplexType)
	 * @see ccsl.elements.statements.StatementsPackage#getInstanceCreation_Type()
	 * @model
	 * @generated
	 */
	ComplexType getType();

	/**
	 * Sets the value of the '{@link ccsl.elements.statements.InstanceCreation#getType <em>Type</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Type</em>' reference.
	 * @see #getType()
	 * @generated
	 */
	void setType(ComplexType value);

} // InstanceCreation
