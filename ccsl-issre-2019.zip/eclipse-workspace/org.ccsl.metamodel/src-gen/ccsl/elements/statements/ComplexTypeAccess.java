/**
 */
package ccsl.elements.statements;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Complex Type Access</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ccsl.elements.statements.StatementsPackage#getComplexTypeAccess()
 * @model
 * @generated
 */
public interface ComplexTypeAccess extends Access {
} // ComplexTypeAccess
