/**
 */
package ccsl.elements.statements;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Variable Access</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ccsl.elements.statements.StatementsPackage#getVariableAccess()
 * @model
 * @generated
 */
public interface VariableAccess extends Access {
} // VariableAccess
