/**
 */
package ccsl.elements.statements;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Branch Control</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ccsl.elements.statements.StatementsPackage#getBranchControl()
 * @model
 * @generated
 */
public interface BranchControl extends ControlFlow {
} // BranchControl
