/**
 */
package ccsl.elements.statements;

import ccsl.elements.Element;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Statement</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ccsl.elements.statements.StatementsPackage#getStatement()
 * @model
 * @generated
 */
public interface Statement extends Element {
} // Statement
