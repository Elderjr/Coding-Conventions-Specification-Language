/**
 */
package ccsl.elements.statements.impl;

import ccsl.elements.statements.BranchControl;
import ccsl.elements.statements.StatementsPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Branch Control</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class BranchControlImpl extends ControlFlowImpl implements BranchControl {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected BranchControlImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return StatementsPackage.Literals.BRANCH_CONTROL;
	}

} //BranchControlImpl
