/**
 */
package ccsl.elements.statements.impl;

import ccsl.elements.statements.StatementsPackage;
import ccsl.elements.statements.SuperMethodInvocation;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Super Method Invocation</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class SuperMethodInvocationImpl extends MethodInvocationImpl implements SuperMethodInvocation {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SuperMethodInvocationImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return StatementsPackage.Literals.SUPER_METHOD_INVOCATION;
	}

} //SuperMethodInvocationImpl
