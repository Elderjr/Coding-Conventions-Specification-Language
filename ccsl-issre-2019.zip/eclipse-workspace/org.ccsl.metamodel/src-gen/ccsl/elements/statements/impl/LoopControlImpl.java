/**
 */
package ccsl.elements.statements.impl;

import ccsl.elements.statements.LoopControl;
import ccsl.elements.statements.StatementsPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Loop Control</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class LoopControlImpl extends ControlFlowImpl implements LoopControl {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected LoopControlImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return StatementsPackage.Literals.LOOP_CONTROL;
	}

} //LoopControlImpl
