/**
 */
package ccsl.elements.statements.impl;

import ccsl.elements.statements.ComplexTypeAccess;
import ccsl.elements.statements.StatementsPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Complex Type Access</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class ComplexTypeAccessImpl extends AccessImpl implements ComplexTypeAccess {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ComplexTypeAccessImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return StatementsPackage.Literals.COMPLEX_TYPE_ACCESS;
	}

} //ComplexTypeAccessImpl
