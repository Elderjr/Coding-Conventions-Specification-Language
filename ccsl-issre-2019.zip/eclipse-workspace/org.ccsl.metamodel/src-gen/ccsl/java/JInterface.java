/**
 */
package ccsl.java;

import ccsl.elements.namedElements.ComplexType;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>JInterface</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ccsl.java.JavaPackage#getJInterface()
 * @model
 * @generated
 */
public interface JInterface extends JElement, ComplexType {
} // JInterface
