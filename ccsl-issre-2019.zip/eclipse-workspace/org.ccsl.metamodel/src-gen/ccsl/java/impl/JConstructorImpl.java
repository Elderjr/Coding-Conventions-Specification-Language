/**
 */
package ccsl.java.impl;

import ccsl.java.JConstructor;
import ccsl.java.JavaPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>JConstructor</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class JConstructorImpl extends JMethodImpl implements JConstructor {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected JConstructorImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return JavaPackage.Literals.JCONSTRUCTOR;
	}

} //JConstructorImpl
