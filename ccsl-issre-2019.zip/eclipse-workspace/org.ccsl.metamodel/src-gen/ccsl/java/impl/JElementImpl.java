/**
 */
package ccsl.java.impl;

import ccsl.java.JElement;
import ccsl.java.JavaPackage;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>JElement</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class JElementImpl extends MinimalEObjectImpl.Container implements JElement {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected JElementImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return JavaPackage.Literals.JELEMENT;
	}

} //JElementImpl
