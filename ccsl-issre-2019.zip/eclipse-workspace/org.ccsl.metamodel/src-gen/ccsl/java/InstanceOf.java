/**
 */
package ccsl.java;

import ccsl.elements.statements.InfixExp;
import ccsl.elements.statements.Statement;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Instance Of</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ccsl.java.JavaPackage#getInstanceOf()
 * @model
 * @generated
 */
public interface InstanceOf extends JElement, Statement, InfixExp {
} // InstanceOf
