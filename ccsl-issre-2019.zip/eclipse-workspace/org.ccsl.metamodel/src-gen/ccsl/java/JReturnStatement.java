/**
 */
package ccsl.java;

import ccsl.elements.statements.Statement;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>JReturn Statement</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ccsl.java.JavaPackage#getJReturnStatement()
 * @model
 * @generated
 */
public interface JReturnStatement extends JElement, Statement {
} // JReturnStatement
