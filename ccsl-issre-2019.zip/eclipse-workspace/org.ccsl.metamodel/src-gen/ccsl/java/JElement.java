/**
 */
package ccsl.java;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>JElement</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ccsl.java.JavaPackage#getJElement()
 * @model
 * @generated
 */
public interface JElement extends EObject {
} // JElement
