/**
 */
package ccsl.java;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>JConstructor</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ccsl.java.JavaPackage#getJConstructor()
 * @model
 * @generated
 */
public interface JConstructor extends JMethod {
} // JConstructor
